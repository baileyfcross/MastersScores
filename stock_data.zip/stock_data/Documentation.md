# Stock Data Metadata: yfinance
The data was sourced from "Yahoo Finance" by using their API in an advertent way by using a popular opensource Python Package.

## Ticker Symbol
Ticker symbols are unique combinations of letters that identify publicly traded companies and their stocks, facilitating easy reference and communication in financial markets. They enable investors to quickly distinguish between different stocks and standardize trading across various exchanges. The date range for analyzing historical market data is crucial as it provides context for stock performance, allowing for comparative analysis, identification of seasonal trends, and understanding the impact of broader economic events.

## Frequency
The data is analyzed from December 1, 2021, to March 31, 2022 as it encompasses peak COVID-19 conditions, influencing market dynamics in the US.

The frequency of the data—daily, weekly, or monthly—affects trend analysis. Daily data captures short-term fluctuations and volatility, which is useful for tactical trading decisions. In contrast, weekly or monthly data smooths out these fluctuations, providing clearer insights into long-term trends and overall market health.

This comprehensive understanding of ticker symbols, date ranges, and data frequency allows investors to make informed decisions based on the historical performance and context of the stocks they are interested in. The provided code effectively retrieves and saves relevant historical data for further analysis.

## Data Fields
I used common fields like Open, High, Low, Close, Volume, and Adjusted Close for each stock csv because it is the standardized framework that is used by most people who are interested in this data. 

Each field offers unique insights: 
- The Open establishes the starting point of trading. 
- High and Low indicate price peaks and troughs, helping to identify resistance and support levels. 
- Close is crucial for technical analysis, serving as a key reference point. 
- Volume reflects trading activity and investor sentiment. 
- Adjusted Close accounts for dividends and splits, providing a clearer picture of a stock's true value over time. 

Together, these fields can be used to perform any sort of meaningful analysis, enabling investors to make informed decisions based on historical trends and market behavior.

## Currency

The prices are denominated in U.S. dollars (USD), providing a consistent framework for domestic investors as my goal was to analyze the impact of COVID-19 on the US Stock Market exclusively. Currency fluctuations are also harder to analyze when looking at multiple currencies as there might other localized factors involved that cause certain currencies to flourish/dip. 

Regarding US Stocks, the any currency fluctuations occurred primarily through the appreciation of the U.S. dollar as investors sought safety. A stronger dollar made U.S. exports more expensive, adversely affecting companies reliant on international sales and potentially dampening stock prices. For foreign investors, currency volatility meant that returns on U.S. investments could vary based on exchange rates, influencing their willingness to invest. Additionally, the dollar's fluctuations mirrored market sentiment about economic recovery, as it reacted to stimulus measures and vaccine rollouts. Overall, these dynamics highlight how currency movements shaped the stock market landscape during the pandemic, affecting investor behavior and corporate strategies.

## Adjustments

Any adjustments are crucial for accurately reflecting historical prices and ensuring reliable comparisons across different periods. For instance, stock splits can distort perceptions of stock performance if not accounted for, while dividend payments provide insights into a company's financial health. Accurate adjustments enable investors to evaluate Total Return, which incorporates both price appreciation and dividends, guiding informed investment decisions. 

These adjustments have not been performed yet, but would definitely be incorporated when any analysis is conducted.

## Limitations
Since the data is technically from a third party source, the information can possibly be incorrect. But considering how big of a name Yahoo is, it can probably be assumed to be reliable. The data is also limited to the spikes of COVID by cases. This does not incorporate the impact of mass hysteria or any of the bandwagoning that occured with COVID during its inital few months of significant but not alarming levels of case rise(s). Considering these factors, any analysis performed would be only useful for analyzing the impact of COVID at its peak not during its overall duration. 
